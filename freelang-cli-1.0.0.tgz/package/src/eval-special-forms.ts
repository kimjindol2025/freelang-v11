// eval-special-forms.ts — FreeLang v9 Special Form Evaluation
// Phase 57 리팩토링: interpreter.ts의 특수 폼을 분리
// fn, async, set!, define, func-ref, call, compose, pipe,
// let, set, if, cond, do/begin/progn, loop, recur, while, and, or, map
// Phase 63: defmacro, macroexpand 추가
// Phase 61: TCO 모드에서 꼬리 위치 함수 호출 → TailCall 토큰 반환
// Phase 66: defstruct — 타입이 있는 레코드 타입
// Phase 96: fl-try — Result 기반 에러 처리

import { Interpreter } from "./interpreter";
import { SExpr, ASTNode, Variable, Literal } from "./ast";
import { isBlock, isControlBlock } from "./ast";
import { tailCall, isTailCall } from "./tco";
import { StructRegistry } from "./struct-system"; // Phase 66
import { ok, err, isOk, isErr, fromThrown, ErrorCategory } from "./result-type"; // Phase 96
import { BytecodeCompiler } from "./compiler"; // Phase 3-E: VM defn 컴파일
import { registerVMFunction } from "./vm-eligible"; // Phase 3-E: VM 함수 등록

const _vmCompiler = new BytecodeCompiler(); // Phase 3-E

export function evalSpecialForm(interp: Interpreter, op: string, expr: SExpr): any {
  const ev = (node: any) => (interp as any).eval(node);
  const callUser = (name: string, a: any[]) => (interp as any).callUserFunction(name, a);
  const callFnVal = (fn: any, a: any[]) => (interp as any).callFunctionValue(fn, a);
  const callAsyncFnVal = (fn: any, a: any[]) => (interp as any).callAsyncFunctionValue(fn, a);
  const callFn = (fn: any, a: any[]) => (interp as any).callFunction(fn, a);
  const ctx = interp.context;

  // ── fn ───────────────────────────────────────────────────────────
  if (op === "fn") {
    if (expr.args.length < 2) throw new Error(`fn requires at least 2 arguments (params and body)`);
    const paramsNode = expr.args[0];
    const params: string[] = [];
    if ((paramsNode as any).kind === "block" && (paramsNode as any).type === "Array") {
      const items = (paramsNode as any).fields.get("items");
      if (Array.isArray(items)) {
        for (const item of items) {
          // v11.1: variable ($x) 또는 bare symbol (x) 모두 허용 → 정식 이름은 $-접두사 포함
          if ((item as any).kind === "variable") {
            const n = (item as Variable).name;
            params.push(n.startsWith("$") ? n.slice(1) : n);
          } else if ((item as any).kind === "literal" && (item as any).type === "symbol") {
            const v = (item as any).value as string;
            params.push(v.startsWith("$") ? v.slice(1) : v);
          }
        }
      }
    }
    const body = expr.args.length === 2
      ? expr.args[1]
      : { kind: "sexpr" as const, op: "do", args: expr.args.slice(1) };
    return {
      kind: "function-value",
      params,
      body,
      capturedEnv: ctx.variables.snapshot(),
      name: undefined,
    };
  }

  // ── defn (v11.1: Clojure 스타일 sugar) ───────────────────────────
  // (defn name [params...] body) → (define name (fn [params...] body))
  if (op === "defn") {
    if (expr.args.length < 3) throw new Error(`defn requires name, params, and body`);
    const nameNode = expr.args[0] as any;
    let name: string;
    if (nameNode.kind === "variable") name = nameNode.name;
    else if (nameNode.kind === "literal" && nameNode.type === "symbol") name = nameNode.value as string;
    else throw new Error(`defn: first argument must be a symbol (function name)`);

    const paramsNode = expr.args[1];
    const bodyArgs = expr.args.slice(2);
    const body = bodyArgs.length === 1
      ? bodyArgs[0]
      : ({ kind: "sexpr" as const, op: "do", args: bodyArgs } as any);

    // (fn [params] body) 를 synth → 현재 scope에서 eval하여 function-value 획득
    const fnExpr: any = { kind: "sexpr", op: "fn", args: [paramsNode, body] };
    const fnValue = (interp as any).evalSExpr(fnExpr);

    // Phase 3-E: VM 함수 컴파일 및 등록
    try {
      const funcChunk = _vmCompiler.compileFunctionBody(fnValue.params, fnValue.body, name);
      const vmFuncObj = {
        _isVMFunc: true,
        _chunk: funcChunk,
        _params: fnValue.params,
        _closure: fnValue.capturedEnv ? [...fnValue.capturedEnv.entries()] : []
      };
      registerVMFunction(name, vmFuncObj);
    } catch {
      // 컴파일 실패 시 이름만 등록 (fallback)
      registerVMFunction(name);
    }

    // name을 set → bare symbol/variable 둘 다로 접근 가능하게 저장
    ctx.variables.set("$" + name, fnValue);
    ctx.variables.set(name, fnValue);
    return fnValue;
  }

  // ── async ─────────────────────────────────────────────────────────
  if (op === "async") {
    if (expr.args.length < 3) throw new Error(`async requires name, params, and body`);
    const nameNode = expr.args[0];
    const name = (nameNode as Variable).name || "async-fn";
    const paramsNode = expr.args[1];
    const params: string[] = [];
    if ((paramsNode as any).kind === "block" && (paramsNode as any).type === "Array") {
      const items = (paramsNode as any).fields.get("items");
      if (Array.isArray(items)) {
        for (const item of items) {
          if ((item as any).kind === "variable") params.push((item as Variable).name);
        }
      }
    }
    return {
      kind: "async-function-value",
      name,
      params,
      body: expr.args[2],
      capturedEnv: ctx.variables.snapshot(),
    };
  }

  // ── set! ──────────────────────────────────────────────────────────
  if (op === "set!") {
    if (expr.args.length < 2) throw new Error(`set! requires a name and a value`);
    const nameNode = expr.args[0];

    // (set! (get $obj "key") value) — map/array 프로퍼티 뮤테이션
    if ((nameNode as any).kind === "sexpr" && (nameNode as any).op === "get") {
      const getArgs = (nameNode as any).args;
      const obj = ev(getArgs[0]);
      const key = ev(getArgs[1]);
      const value = ev(expr.args[1]);
      if (obj !== null && typeof obj === "object") {
        const k = typeof key === "string" && key.startsWith(":") ? key.slice(1) : String(key);
        obj[k] = value;
      }
      return ev(expr.args[1]);
    }

    let name: string;
    if ((nameNode as any).kind === "variable") {
      name = "$" + (nameNode as any).name;
    } else if ((nameNode as any).kind === "literal") {
      name = "$" + (nameNode as any).value;
    } else {
      throw new Error(`set!: first argument must be a symbol`);
    }
    const value = ev(expr.args[1]);
    if (!ctx.variables.mutate(name, value)) ctx.variables.set(name, value);
    return value;
  }

  // ── define ────────────────────────────────────────────────────────
  if (op === "define") {
    if (expr.args.length < 2) throw new Error(`define requires a name and a value`);
    const nameNode = expr.args[0];
    let name: string;
    if ((nameNode as any).kind === "literal") {
      name = (nameNode as Literal).value as string;
    } else if ((nameNode as any).kind === "variable") {
      name = (nameNode as Variable).name;
    } else {
      throw new Error(`define: first argument must be a symbol or string`);
    }

    // 3-arg form: (define name [params] body) → define function
    if (expr.args.length >= 3) {
      const paramsNode = expr.args[1];
      const bodyNode = expr.args.length === 3
        ? expr.args[2]
        : { kind: "sexpr" as const, op: "do", args: expr.args.slice(2) };
      const items = (paramsNode as any).kind === "block" && (paramsNode as any).type === "Array"
        ? (paramsNode as any).fields.get("items") || []
        : (paramsNode as any).kind === "array"
          ? (paramsNode as any).items || []
          : [];
      const params = (items as any[]).map((item: any) => {
        if (item.kind === "variable") return item.name.startsWith("$") ? item.name : "$" + item.name;
        if (item.kind === "literal") return "$" + item.value;
        return "$" + (item.name || item.value || "?");
      });
      ctx.functions.set(name, { name, params, body: bodyNode });
      return null;
    }

    const value = ev(expr.args[1]);
    if (value !== null && value !== undefined && (value as any).kind === "function-value") {
      const funcDef = {
        name,
        params: (value as any).params,
        body: (value as any).body,
        capturedEnv: (value as any).capturedEnv,
      };
      ctx.functions.set(name, funcDef);
      if (ctx.typeChecker) {
        const paramTypes = (value as any).params.map(() => ({ kind: "type" as const, name: "any" }));
        ctx.typeChecker.registerFunction(name, paramTypes, { kind: "type" as const, name: "any" });
      }
      return value;
    } else {
      ctx.variables.set("$" + name, value);
      return value;
    }
  }

  // ── func-ref ──────────────────────────────────────────────────────
  if (op === "func-ref") {
    if (expr.args.length < 1) throw new Error(`func-ref requires function name`);
    const funcName = (expr.args[0] as any).name || String(expr.args[0]);
    const func = ctx.functions.get(funcName);
    if (!func) throw new Error(`Function not found: ${funcName}`);
    return {
      kind: "function-value",
      params: func.params,
      body: func.body,
      capturedEnv: ctx.variables.snapshot(),
      name: funcName,
    };
  }

  // ── call ──────────────────────────────────────────────────────────
  if (op === "call") {
    if (expr.args.length < 1) throw new Error(`call requires function as first argument`);
    const fn = ev(expr.args[0]);
    const evaluatedArgs = expr.args.slice(1).map((a) => ev(a));
    if ((fn as any).kind === "builtin-function") return (fn as any).fn(evaluatedArgs);
    if ((fn as any).kind === "function-value") return callFnVal(fn, evaluatedArgs);
    if ((fn as any).kind === "async-function-value") return callAsyncFnVal(fn, evaluatedArgs);
    if (typeof fn === "string") return callUser(fn, evaluatedArgs);
    throw new Error(`call expects function-value, got ${(fn as any).kind || typeof fn}`);
  }

  // ── compose ───────────────────────────────────────────────────────
  if (op === "compose") {
    if (expr.args.length < 2) throw new Error(`compose requires at least 2 functions`);
    const funcsToCompose = expr.args.map((arg) => {
      if ((arg as any).kind === "literal" && (arg as any).type === "symbol") {
        const fnName = (arg as Literal).value as string;
        if (ctx.functions.has(fnName)) return { _isFunctionName: true, name: fnName };
        throw new Error(`compose: '${fnName}' is not a function`);
      } else if ((arg as any).kind === "variable") {
        const fnName = (arg as Variable).name;
        if (ctx.functions.has(fnName)) return { _isFunctionName: true, name: fnName };
        const value = ctx.variables.get(fnName);
        if (value && ((value as any).kind === "function-value" || typeof value === "function")) return value;
        throw new Error(`compose: '${fnName}' is not a function`);
      } else {
        const fn = ev(arg);
        if (typeof fn !== "function" && (fn as any).kind !== "function-value") throw new Error(`compose: argument is not a function`);
        return fn;
      }
    });
    return (x: any) => {
      let result = x;
      for (let i = funcsToCompose.length - 1; i >= 0; i--) {
        const fn = funcsToCompose[i];
        if ((fn as any)._isFunctionName) result = callUser((fn as any).name, [result]);
        else result = callFn(fn, [result]);
      }
      return result;
    };
  }

  // ── pipe ──────────────────────────────────────────────────────────
  if (op === "pipe") {
    if (expr.args.length < 2) throw new Error(`pipe requires at least a value and one function`);
    let pipeValue = ev(expr.args[0]);
    for (let i = 1; i < expr.args.length; i++) {
      const fnArg = expr.args[i];
      let pipeResult: any;
      if ((fnArg as any).kind === "literal" && (fnArg as any).type === "symbol") {
        const fnName = (fnArg as Literal).value as string;
        if (ctx.functions.has(fnName)) pipeResult = callUser(fnName, [pipeValue]);
        else throw new Error(`Unknown function: ${fnName}`);
      } else if ((fnArg as any).kind === "variable") {
        const fnName = (fnArg as Variable).name;
        if (ctx.functions.has(fnName)) pipeResult = callUser(fnName, [pipeValue]);
        else if (ctx.variables.has(fnName)) pipeResult = callFn(ctx.variables.get(fnName), [pipeValue]);
        else throw new Error(`Unknown function or variable: ${fnName}`);
      } else {
        const fn = ev(fnArg);
        pipeResult = callFn(fn, [pipeValue]);
      }
      pipeValue = pipeResult;
    }
    return pipeValue;
  }

  // ── -> (thread-first) ────────────────────────────────────────────
  // (-> val (f1 extra) f2 (f3 a b))
  // => (f3 (f2 (f1 val extra)) a b)
  // val이 각 form의 첫 번째 인자 위치에 삽입됨
  if (op === "->") {
    if (expr.args.length < 2) throw new Error(`-> requires at least a value and one step`);
    const TMP_VAR = "__thread_first_tmp__";
    let val = ev(expr.args[0]);
    for (let i = 1; i < expr.args.length; i++) {
      const form = expr.args[i];
      const fk = (form as any).kind;
      if (fk === "sexpr") {
        // (f extra-args...) → (f val extra-args...)
        const sform = form as SExpr;
        ctx.variables.set(TMP_VAR, val);
        const tmpVar: Variable = { kind: "variable", name: TMP_VAR };
        const newSexpr: SExpr = { kind: "sexpr", op: sform.op, args: [tmpVar, ...sform.args] };
        val = ev(newSexpr);
        ctx.variables.delete(TMP_VAR);
      } else if (fk === "variable") {
        const fnName = (form as Variable).name;
        if (ctx.functions.has(fnName)) val = callUser(fnName, [val]);
        else if (ctx.variables.has(fnName)) val = callFn(ctx.variables.get(fnName), [val]);
        else throw new Error(`->: unknown function or variable: ${fnName}`);
      } else if (fk === "literal" && (form as Literal).type === "symbol") {
        const fnName = (form as Literal).value as string;
        if (ctx.functions.has(fnName)) val = callUser(fnName, [val]);
        else throw new Error(`->: unknown function: ${fnName}`);
      } else {
        const fn = ev(form);
        val = callFn(fn, [val]);
      }
    }
    return val;
  }

  // ── ->> (thread-last) ────────────────────────────────────────────
  // (->> val (f1 extra) f2 (f3 a b))
  // => (f3 a b (f2 (f1 val extra)))
  // val이 각 form의 마지막 인자 위치에 삽입됨
  if (op === "->>") {
    if (expr.args.length < 2) throw new Error(`->> requires at least a value and one step`);
    const TMP_VAR = "__thread_last_tmp__";
    let val = ev(expr.args[0]);
    for (let i = 1; i < expr.args.length; i++) {
      const form = expr.args[i];
      const fk = (form as any).kind;
      if (fk === "sexpr") {
        // (f existing-args...) → (f existing-args... val)
        const sform = form as SExpr;
        ctx.variables.set(TMP_VAR, val);
        const tmpVar: Variable = { kind: "variable", name: TMP_VAR };
        const newSexpr: SExpr = { kind: "sexpr", op: sform.op, args: [...sform.args, tmpVar] };
        val = ev(newSexpr);
        ctx.variables.delete(TMP_VAR);
      } else if (fk === "variable") {
        const fnName = (form as Variable).name;
        if (ctx.functions.has(fnName)) val = callUser(fnName, [val]);
        else if (ctx.variables.has(fnName)) val = callFn(ctx.variables.get(fnName), [val]);
        else throw new Error(`->>: unknown function or variable: ${fnName}`);
      } else if (fk === "literal" && (form as Literal).type === "symbol") {
        const fnName = (form as Literal).value as string;
        if (ctx.functions.has(fnName)) val = callUser(fnName, [val]);
        else throw new Error(`->>: unknown function: ${fnName}`);
      } else {
        const fn = ev(form);
        val = callFn(fn, [val]);
      }
    }
    return val;
  }

  // ── |> (simple pipe, alias for pipe) ─────────────────────────────
  // (|> val f1 f2 f3) ≡ (pipe val f1 f2 f3)
  if (op === "|>") {
    if (expr.args.length < 2) throw new Error(`|> requires at least a value and one function`);
    let pipeVal = ev(expr.args[0]);
    for (let i = 1; i < expr.args.length; i++) {
      const fnArg = expr.args[i];
      const fk = (fnArg as any).kind;
      if (fk === "literal" && (fnArg as Literal).type === "symbol") {
        const fnName = (fnArg as Literal).value as string;
        if (ctx.functions.has(fnName)) pipeVal = callUser(fnName, [pipeVal]);
        else throw new Error(`|>: unknown function: ${fnName}`);
      } else if (fk === "variable") {
        const fnName = (fnArg as Variable).name;
        if (ctx.functions.has(fnName)) pipeVal = callUser(fnName, [pipeVal]);
        else if (ctx.variables.has(fnName)) pipeVal = callFn(ctx.variables.get(fnName), [pipeVal]);
        else throw new Error(`|>: unknown function or variable: ${fnName}`);
      } else {
        const fn = ev(fnArg);
        pipeVal = callFn(fn, [pipeVal]);
      }
    }
    return pipeVal;
  }

  // ── let ───────────────────────────────────────────────────────────
  if (op === "let") {
    return evalLet(interp, expr.args);
  }

  // ── set ───────────────────────────────────────────────────────────
  if (op === "set") {
    if (expr.args.length !== 2) throw new Error(`set requires exactly 2 arguments: (set $var new-value)`);
    const varNode = expr.args[0] as any;
    let varName: string;
    if (varNode.kind === "variable") varName = varNode.name;
    else if (varNode.kind === "literal" && varNode.type === "symbol") varName = "$" + varNode.value;
    else throw new Error(`set: first argument must be a variable`);
    const newValue = ev(expr.args[1]);
    if (!ctx.variables.mutate(varName, newValue)) throw new Error(`set: variable ${varName} not found in scope`);
    return newValue;
  }

  // ── if ────────────────────────────────────────────────────────────
  if (op === "if") {
    const condition = ev(expr.args[0]);
    const branch = condition ? expr.args[1] : (expr.args[2] || null);
    if (branch === null) return null;
    // Phase 61: TCO 모드 — 꼬리 위치의 사용자 함수 호출을 TailCall 토큰으로 반환
    if ((interp as any).tcoMode && branch !== null) {
      const b = branch as any;
      if (b.kind === "sexpr") {
        const bop = b.op;
        // 사용자 정의 함수이거나 아직 알 수 없는 함수 호출 — 일단 eval해서 확인
        // (builtin이면 그냥 실행, user-func이면 TailCall)
        const ctx = interp.context;
        if (typeof bop === "string" && ctx.functions.has(bop)) {
          // 꼬리 위치 user-function 호출 → TailCall 토큰 반환 (스택 없이)
          const tailArgs = b.args.map((a: any) => ev(a));
          return tailCall(bop, tailArgs);
        }
      }
    }
    return ev(branch);
  }

  // ── cond ──────────────────────────────────────────────────────────
  if (op === "cond") {
    return evalCond(interp, expr.args);
  }

  // ── do / begin / progn ───────────────────────────────────────────
  if (op === "do" || op === "begin" || op === "progn") {
    let result: any = null;
    for (const arg of expr.args) {
      if (isBlock(arg) && isControlBlock(arg as any)) {
        (interp as any).evalBlock(arg);
        result = null;
        continue;
      }
      result = ev(arg);
    }
    return result;
  }

  // ── loop ──────────────────────────────────────────────────────────
  if (op === "loop") {
    const bindingsNode = expr.args[0];
    const bodyNodes = expr.args.slice(1);
    const bindingItems: any[] =
      (bindingsNode as any).kind === "array"
        ? (bindingsNode as any).items || []
        : (bindingsNode as any).kind === "block" && (bindingsNode as any).type === "Array"
          ? (bindingsNode as any).fields?.get?.("items") || []
          : [];

    const loopVars: string[] = [];
    const loopInits: any[] = [];
    for (let i = 0; i < bindingItems.length; i += 2) {
      const varNode = bindingItems[i];
      const valNode = bindingItems[i + 1];
      const varName = varNode.kind === "variable" ? varNode.name
        : varNode.kind === "literal" ? String(varNode.value)
        : String(varNode.name || varNode.value);
      loopVars.push(varName);
      loopInits.push(ev(valNode));
    }

    ctx.variables.push();
    for (let i = 0; i < loopVars.length; i++) {
      ctx.variables.set(loopVars[i], loopInits[i]);
    }

    let result: any = null;
    const maxIter = 100000;
    let iter = 0;
    try {
      while (iter++ < maxIter) {
        let recurred = false;
        for (const bodyNode of bodyNodes) {
          result = ev(bodyNode);
          if (result && typeof result === "object" && result.__FL_RECUR__) {
            const newVals = result.__args as any[];
            for (let i = 0; i < loopVars.length && i < newVals.length; i++) {
              ctx.variables.set(loopVars[i], newVals[i]);
            }
            recurred = true;
            break;
          }
        }
        if (!recurred) break;
      }
    } finally {
      ctx.variables.pop();
    }
    return result;
  }

  // ── recur ─────────────────────────────────────────────────────────
  if (op === "recur") {
    const newVals = expr.args.map((a) => ev(a));
    return { __FL_RECUR__: true, __args: newVals };
  }

  // ── while ─────────────────────────────────────────────────────────
  if (op === "while") {
    let result: any = null;
    while (ev(expr.args[0])) {
      for (let i = 1; i < expr.args.length; i++) result = ev(expr.args[i]);
    }
    return result;
  }

  // ── and (short-circuit) ───────────────────────────────────────────
  if (op === "and") {
    let result: any = true;
    for (const arg of expr.args) {
      result = ev(arg);
      if (!result) return result;
    }
    return result;
  }

  // ── or (short-circuit) ────────────────────────────────────────────
  if (op === "or") {
    for (const arg of expr.args) {
      const result = ev(arg);
      if (result) return result;
    }
    return false;
  }

  // ── map (inline comprehension, 3-arg form) ────────────────────────
  if (op === "map" && expr.args.length === 3) {
    const arr = ev(expr.args[0]);
    const paramNode = expr.args[1];
    const bodyNode = expr.args[2];
    const items: any[] =
      (paramNode as any).kind === "block" && (paramNode as any).type === "Array"
        ? (paramNode as any).fields.get?.("items") || []
        : (paramNode as any).kind === "array"
          ? (paramNode as any).items || []
          : [];
    const paramNames = items.map((item: any) => {
      if (item.kind === "variable") return item.name;
      if (item.kind === "literal") return "$" + item.value;
      return "$" + (item.name || item.value || "_");
    });
    if (Array.isArray(arr) && paramNames.length > 0) {
      return arr.map((elem: any) => {
        ctx.variables.push();
        ctx.variables.set(paramNames[0], elem);
        try {
          return ev(bodyNode);
        } finally {
          ctx.variables.pop();
        }
      });
    }
    // Fall through: return undefined (caller will evaluate args and try builtins)
    return undefined;
  }

  // ── defstruct ─────────────────────────────────────────────────────
  // (defstruct Point [:x :float :y :float])
  // 자동 생성:
  //   (Point 1.0 2.0)       → {:x 1.0 :y 2.0 :__type "Point"}
  //   (Point? v)            → true/false
  //   (Point.x v)           → v.x
  if (op === "defstruct") {
    if (expr.args.length < 2) {
      throw new Error(`defstruct requires a name and a field vector`);
    }

    // 1. 이름 추출
    const nameNode = expr.args[0] as any;
    const structName: string =
      nameNode.kind === "literal"  ? String(nameNode.value)
      : nameNode.kind === "variable" ? nameNode.name
      : String(nameNode.value ?? nameNode.name ?? "");

    if (!structName) throw new Error(`defstruct: struct name is required`);

    // 2. 필드 벡터 파싱 [:x :float :y :float]
    const fieldsNode = expr.args[1] as any;
    const fields: Array<{ name: string; type: string }> = [];

    if (fieldsNode.kind === "block" && fieldsNode.type === "Array") {
      const items = fieldsNode.fields.get("items");
      if (Array.isArray(items)) {
        for (let i = 0; i < items.length; i += 2) {
          const nameItem = items[i] as any;
          const typeItem = items[i + 1] as any;
          // 키워드 (:x) or 변수 (x)
          const fieldName =
            nameItem.kind === "keyword" ? nameItem.name
            : nameItem.kind === "variable" ? nameItem.name
            : nameItem.kind === "literal"  ? String(nameItem.value)
            : "";
          const fieldType =
            typeItem === undefined            ? "any"
            : typeItem.kind === "keyword"    ? typeItem.name
            : typeItem.kind === "variable"   ? typeItem.name
            : typeItem.kind === "literal"    ? String(typeItem.value)
            : "any";
          if (fieldName) fields.push({ name: fieldName, type: fieldType });
        }
      }
    }

    // 3. StructRegistry에 등록
    const registry: StructRegistry = ctx.structs;
    registry.define({ name: structName, fields });

    // 4. constructor 등록 — (Point 1.0 2.0)
    const ctor = registry.makeConstructor(structName);
    ctx.functions.set(structName, {
      name: structName,
      params: fields.map((f) => f.name),
      body: { kind: "literal", type: "null", value: null } as any,
      capturedEnv: new Map([["__struct_ctor__", ctor]]),
    });
    // native 함수로도 등록 (eval-builtins fallback이 아닌 직접 호출)
    (ctx as any)[`__native_${structName}`] = ctor;

    // 5. predicate 등록 — (Point? v)
    const pred = registry.makePredicate(structName);
    (ctx as any)[`__native_${structName}?`] = pred;

    // 6. field accessor 등록 — (Point.x v), (Point.y v) ...
    for (const field of fields) {
      const accessorName = `${structName}.${field.name}`;
      const acc = registry.makeAccessor(structName, field.name);
      (ctx as any)[`__native_${accessorName}`] = acc;
    }

    return null;
  }

  // ── defmacro ──────────────────────────────────────────────────────
  // (defmacro name [$cond $body] (if $cond $body nil))
  if (op === "defmacro") {
    if (expr.args.length < 3) throw new Error(`defmacro requires name, params, and body`);
    const nameNode = expr.args[0] as any;
    const macroName: string = nameNode.kind === "literal" ? String(nameNode.value)
      : nameNode.kind === "variable" ? nameNode.name
      : String(nameNode.value ?? nameNode.name ?? "");

    const paramsNode = expr.args[1] as any;
    const params: string[] = [];
    if (paramsNode.kind === "block" && paramsNode.type === "Array") {
      const items = paramsNode.fields.get("items");
      if (Array.isArray(items)) {
        for (const item of items as any[]) {
          if (item.kind === "variable") params.push(item.name.startsWith("$") ? item.name : "$" + item.name);
          else if (item.kind === "literal") params.push("$" + item.value);
        }
      }
    }
    const body = expr.args[2];
    ctx.macroExpander.define(macroName, params, body);
    return null;
  }

  // ── macroexpand ───────────────────────────────────────────────────
  // (macroexpand '(when true (println "yes"))) → 확장된 AST 출력 (디버깅용)
  if (op === "macroexpand") {
    if (expr.args.length < 1) throw new Error(`macroexpand requires 1 argument`);
    const form = expr.args[0];
    const expanded = ctx.macroExpander.expand(form);
    return ctx.macroExpander.astToString(expanded);
  }

  // ── defprotocol ───────────────────────────────────────────────────
  // (defprotocol Serializable
  //   [serialize [$self] :string]
  //   [deserialize [$data] :any])
  if (op === "defprotocol") {
    if (expr.args.length < 1) throw new Error(`defprotocol requires a name`);
    const nameNode = expr.args[0] as any;
    const protoName: string =
      nameNode.kind === "variable" ? nameNode.name
      : nameNode.kind === "literal" ? String(nameNode.value)
      : String(nameNode.name ?? nameNode.value ?? "");

    const methods: Array<{ name: string; params: string[]; returnType?: string }> = [];

    for (let i = 1; i < expr.args.length; i++) {
      const sigNode = expr.args[i] as any;
      if (sigNode.kind !== "block" || sigNode.type !== "Array") continue;
      const items = sigNode.fields.get("items");
      if (!Array.isArray(items) || items.length < 1) continue;

      const methodNameNode = items[0] as any;
      const methodName: string =
        methodNameNode.kind === "variable" ? methodNameNode.name
        : methodNameNode.kind === "literal" ? String(methodNameNode.value)
        : String(methodNameNode.name ?? methodNameNode.value ?? "");

      const params: string[] = [];
      if (items.length > 1) {
        const paramsNode = items[1] as any;
        if (paramsNode.kind === "block" && paramsNode.type === "Array") {
          const pItems = paramsNode.fields.get("items");
          if (Array.isArray(pItems)) {
            for (const p of pItems as any[]) {
              if (p.kind === "variable") params.push(p.name);
              else if (p.kind === "literal") params.push("$" + p.value);
            }
          }
        }
      }

      let returnType: string | undefined;
      if (items.length > 2) {
        const rtNode = items[2] as any;
        if (rtNode.kind === "keyword") returnType = rtNode.name;
        else if (rtNode.kind === "literal") returnType = String(rtNode.value);
      }

      methods.push({ name: methodName, params, returnType });
    }

    ctx.protocols.defineProtocol({ name: protoName, methods });
    return null;
  }

  // ── impl ──────────────────────────────────────────────────────────
  // (impl Serializable Point
  //   [serialize [$self] (str "(" $self.x "," $self.y ")")]
  //   [deserialize [$data] {:x 0.0 :y 0.0}])
  if (op === "impl") {
    if (expr.args.length < 3) throw new Error(`impl requires protocol name, type name, and at least one method`);

    const protoNameNode = expr.args[0] as any;
    const protoName: string =
      protoNameNode.kind === "variable" ? protoNameNode.name
      : protoNameNode.kind === "literal" ? String(protoNameNode.value)
      : String(protoNameNode.name ?? protoNameNode.value ?? "");

    const typeNameNode = expr.args[1] as any;
    const typeName: string =
      typeNameNode.kind === "variable" ? typeNameNode.name
      : typeNameNode.kind === "literal" ? String(typeNameNode.value)
      : String(typeNameNode.name ?? typeNameNode.value ?? "");

    const implMethods = new Map<string, { params: string[]; body: any }>();

    for (let i = 2; i < expr.args.length; i++) {
      const implNode = expr.args[i] as any;
      if (implNode.kind !== "block" || implNode.type !== "Array") continue;
      const items = implNode.fields.get("items");
      if (!Array.isArray(items) || items.length < 3) continue;

      const methodNameNode = items[0] as any;
      const methodName: string =
        methodNameNode.kind === "variable" ? methodNameNode.name
        : methodNameNode.kind === "literal" ? String(methodNameNode.value)
        : String(methodNameNode.name ?? methodNameNode.value ?? "");

      const params: string[] = [];
      const paramsNode = items[1] as any;
      if (paramsNode.kind === "block" && paramsNode.type === "Array") {
        const pItems = paramsNode.fields.get("items");
        if (Array.isArray(pItems)) {
          for (const p of pItems as any[]) {
            if (p.kind === "variable") params.push(p.name);
            else if (p.kind === "literal") params.push("$" + p.value);
          }
        }
      }

      const body = items[2];
      implMethods.set(methodName, { params, body });
    }

    ctx.protocols.defineImpl({ protocolName: protoName, typeName, methods: implMethods });
    return null;
  }

  // ── parallel ──────────────────────────────────────────────────────
  // (parallel expr1 expr2 ...) → [result1, result2, ...]
  // 동기 버전: 순차 실행 후 배열 반환 (FreeLangPromise는 resolve 후 반환)
  if (op === "parallel") {
    if (expr.args.length === 0) return [];
    const results: any[] = [];
    for (const arg of expr.args) {
      let val = ev(arg);
      // FreeLangPromise면 resolved 값 추출 시도
      if (val && typeof val === "object" && typeof val.getValue === "function") {
        try { val = val.getValue(); } catch { val = null; }
      }
      results.push(val);
    }
    return results;
  }

  // ── race ──────────────────────────────────────────────────────────
  // (race expr1 expr2 ...) → 첫 번째로 완료된 결과 (동기 버전: 첫 번째 non-null 반환)
  if (op === "race") {
    if (expr.args.length === 0) return null;
    let firstResult: any = undefined;
    for (const arg of expr.args) {
      let val = ev(arg);
      if (val && typeof val === "object" && typeof val.getValue === "function") {
        try { val = val.getValue(); } catch { val = null; }
      }
      if (firstResult === undefined) firstResult = val;
      if (val !== null && val !== undefined) return val;
    }
    return firstResult ?? null;
  }

  // ── with-timeout ──────────────────────────────────────────────────
  // (with-timeout ms expr) → result or null
  // 동기 버전: ms는 무시하고 즉시 실행 (비동기 환경 없으므로)
  if (op === "with-timeout") {
    if (expr.args.length < 2) return null;
    // expr.args[0] = ms (무시), expr.args[1] = expression
    try {
      let val = ev(expr.args[1]);
      if (val && typeof val === "object" && typeof val.getValue === "function") {
        try { val = val.getValue(); } catch { val = null; }
      }
      return val;
    } catch {
      return null;
    }
  }

  // ── Phase 96: fl-try ─────────────────────────────────────────────────
  // (fl-try expr)
  // (fl-try expr :on-err fn)
  // (fl-try expr :on-type-error fn :on-not-found fn :on-io fn :default fn)
  if (op === "fl-try") {
    if (expr.args.length < 1) throw new Error(`fl-try requires at least 1 argument`);
    const bodyNode = expr.args[0];

    // 나머지 인자에서 키워드-핸들러 쌍 추출
    // 파서: :on-err → {kind:"literal", type:"string", value:"on-err"} (콜론 제거)
    //       또는 {kind:"keyword", name:"on-err"} 또는 {kind:"keyword", value:"on-err"}
    const FL_TRY_KEYS = new Set([
      "on-err", "on-type-error", "on-not-found", "on-io", "on-arity",
      "on-ai", "on-timeout", "on-runtime", "default",
    ]);
    const handlers = new Map<string, any>();
    let i = 1;
    while (i < expr.args.length) {
      const keyNode = expr.args[i] as any;
      let key: string | null = null;
      if (keyNode.kind === "keyword") {
        const v = String(keyNode.name ?? keyNode.value ?? "");
        if (FL_TRY_KEYS.has(v)) key = v;
      } else if (keyNode.kind === "literal" && keyNode.type === "string") {
        // :on-err → "on-err" (파서가 콜론 제거), 또는 ":on-err" (콜론 포함)
        const v = keyNode.value.startsWith(":") ? keyNode.value.slice(1) : keyNode.value;
        if (FL_TRY_KEYS.has(v)) key = v;
      }
      if (key !== null && i + 1 < expr.args.length) {
        handlers.set(key, ev(expr.args[i + 1]));
        i += 2;
      } else {
        i++;
      }
    }

    // 본문 실행 — Result로 래핑
    let result: any;
    try {
      const val = ev(bodyNode);
      // 이미 Result 타입이면 그대로, 아니면 ok로 래핑
      if (val && typeof val === "object" && (val._tag === "Ok" || val._tag === "Err")) {
        result = val;
      } else {
        result = ok(val);
      }
    } catch (e: unknown) {
      const flErr = fromThrown(e);
      result = flErr;
    }

    // 핸들러 처리
    if (isErr(result)) {
      const e = result;
      // 카테고리별 핸들러
      const categoryHandlerMap: Record<string, ErrorCategory> = {
        "on-type-error": ErrorCategory.TYPE_ERROR,
        "on-not-found": ErrorCategory.NOT_FOUND,
        "on-io": ErrorCategory.IO,
        "on-arity": ErrorCategory.ARITY,
        "on-ai": ErrorCategory.AI,
        "on-timeout": ErrorCategory.TIMEOUT,
      };

      // 카테고리 매칭 핸들러 우선
      let handled = false;
      for (const [handlerKey, category] of Object.entries(categoryHandlerMap)) {
        if (handlers.has(handlerKey) && e.category === category) {
          const fn = handlers.get(handlerKey);
          const handlerResult = callFnVal(fn, [e]);
          return handlerResult;
        }
      }

      // :on-err — 모든 에러
      if (!handled && handlers.has("on-err")) {
        const fn = handlers.get("on-err");
        return callFnVal(fn, [e]);
      }

      // :default — 나머지
      if (!handled && handlers.has("default")) {
        const fn = handlers.get("default");
        return callFnVal(fn, [e]);
      }

      // 핸들러 없으면 err 값 그대로 반환
      return result;
    }

    return result;
  }

  throw new Error(`evalSpecialForm: unknown op "${op}"`);
}

// ── Helper: evalLet (v11.1: 1차원/2차원 대괄호 + bare symbol 모두 지원) ───
function evalLet(interp: Interpreter, args: ASTNode[]): any {
  if (args.length < 2) throw new Error(`let requires at least 2 arguments`);
  const bindings = args[0];
  const ctx = interp.context;
  const ev = (node: any) => (interp as any).eval(node);

  const toVarName = (node: any): string => {
    if (node?.kind === "variable") {
      const n = node.name as string;
      return n.startsWith("$") ? n : "$" + n;
    }
    if (node?.kind === "literal" && node.type === "symbol") {
      const v = node.value as string;
      return v.startsWith("$") ? v : "$" + v;
    }
    throw new Error(`Invalid binding variable: expected symbol or variable, got ${node?.kind}`);
  };

  ctx.variables.push();

  if ((bindings as any).kind === "block" && (bindings as any).type === "Array") {
    const items = (bindings as any).fields.get("items");
    if (Array.isArray(items) && items.length > 0) {
      // 감지: 첫 원소가 Array block 이면 2차원 ([[$x expr] [$y expr]])
      //       그렇지 않으면 1차원 ([$x expr $y expr] or [x expr y expr])
      const isNested = items[0]?.kind === "block" && items[0]?.type === "Array";

      // v11.10: 혼합 감지 — 모든 원소가 동일한 구조여야 함
      for (let i = 1; i < items.length; i++) {
        const cur = items[i]?.kind === "block" && items[i]?.type === "Array";
        if (cur !== isNested) {
          ctx.variables.pop();
          throw new Error(`let: 바인딩 형식이 일관되지 않음 (2차원 [[$x ...]] 와 1차원 [$x ...] 혼합 불가, index=${i})`);
        }
      }

      if (isNested) {
        // 기존 2차원 경로 (v11 호환)
        for (const item of items) {
          if ((item as any).kind === "block" && (item as any).type === "Array") {
            const bindingItems = (item as any).fields.get("items");
            if (Array.isArray(bindingItems) && bindingItems.length >= 2) {
              const varName = toVarName(bindingItems[0]);
              ctx.variables.set(varName, ev(bindingItems[1]));
            }
          }
        }
      } else {
        // v11.1 신규: 1차원 평탄 문법
        if (items.length % 2 !== 0) {
          ctx.variables.pop();
          throw new Error(`let: expected even number of binding items, got ${items.length}`);
        }
        for (let i = 0; i < items.length; i += 2) {
          const varName = toVarName(items[i]);
          ctx.variables.set(varName, ev(items[i + 1]));
        }
      }
    }
  }

  let result: any = null;
  try {
    for (let bodyIdx = 1; bodyIdx < args.length; bodyIdx++) {
      result = ev(args[bodyIdx]);
    }
  } finally {
    ctx.variables.pop();
  }
  return result;
}

// ── Helper: evalCond ──────────────────────────────────────────────
function evalCond(interp: Interpreter, args: ASTNode[]): any {
  const ev = (node: any) => (interp as any).eval(node);
  for (const arg of args) {
    let testNode: any = null;
    let bodyNodes: any[] = [];

    // [test result...] Array block 형식
    if ((arg as any).kind === "block" && (arg as any).type === "Array") {
      const items = (arg as any).fields.get("items");
      if (Array.isArray(items) && items.length >= 2) {
        testNode = items[0];
        bodyNodes = items.slice(1);
      }
    }
    // ((test-expr) body...) → parser creates SExpr{op:"do", args:[test, body...]}
    else if ((arg as any).kind === "sexpr" && (arg as any).op === "do" && (arg as any).args.length >= 2) {
      testNode = (arg as any).args[0];
      bodyNodes = (arg as any).args.slice(1);
    }
    // (test body) → SExpr where op is test symbol and args is rest
    // e.g. (true result) → SExpr{op:"true", args:[result]}
    else if ((arg as any).kind === "sexpr" && (arg as any).args.length >= 1) {
      const s = arg as any;
      testNode = { kind: "literal", type: "boolean", value: s.op === "true" ? true : s.op === "false" ? false : s.op === "else" ? true : undefined };
      if (testNode.value === undefined) {
        // op is a symbol test — reconstruct as variable lookup or literal
        testNode = { kind: "variable", name: s.op.startsWith("$") ? s.op : "$" + s.op };
      }
      bodyNodes = s.args;
    }

    if (testNode && bodyNodes.length >= 1) {
      const test = ev(testNode);
      if (test) {
        let result: any = null;
        for (const b of bodyNodes) result = ev(b);
        return result;
      }
    }
  }
  return null;
}
